
#demo of len(string)
s='learning python is fun'
print("length of",s,"is",len(s))